import os
import sys

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'  # 隐藏pygame欢迎信息

# 导入必要的库
import pygame
import random

# 初始化Pygame引擎
pygame.init()
pygame.mixer.init()  # 初始化音频模块

# ---------- 游戏常量定义 ----------
# 颜色定义（RGB格式）
COLORS = {
    "BLACK": (0, 0, 0),
    "WHITE": (255, 255, 255),
    "RED": (255, 0, 0),
    "GREEN": (0, 255, 0),
    "DARK_GREEN": (0, 200, 0),
    "GRID": (30, 30, 30),
    "BUTTON": (50, 50, 160),
    "BUTTON_HOVER": (70, 70, 200),
    "SCROLLBAR": (100, 100, 150)
}

# 窗口尺寸设置
WINDOW_SIZE = (800, 600)
CELL_SIZE = 20

# 游戏状态常量
STATES = {
    "MAIN_MENU": 0,
    "GAME_ACTIVE": 1,
    "GAME_OVER": 2,
    "VIEW_HIGHSCORES": 3
}

# 初始化游戏窗口
screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption("贪吃蛇大作战")
clock = pygame.time.Clock()

# 资源文件路径
HIGHSCORE_FILE = "highscores.txt"
MUSIC_FILE = "background music.mp3"
FONT_FILE = "msyh.ttc"


# ---------- 工具函数 ----------
def resource_path(relative_path):
    """获取打包后的资源绝对路径"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


def get_highscores():
    """获取历史最高分"""
    try:
        with open(resource_path(HIGHSCORE_FILE), 'r') as f:
            return sorted([int(line.strip()) for line in f], reverse=True)
    except:
        return []


def save_highscore(score):
    """保存最高分"""
    highscores = get_highscores()
    highscores.append(score)
    highscores = sorted(list(set(highscores)), reverse=True)[:10]  # 去重保留前10

    with open(resource_path(HIGHSCORE_FILE), 'w') as f:
        for s in highscores:
            f.write(f"{s}\n")


# ---------- 游戏组件类 ----------
class Button:
    """按钮控件"""

    def __init__(self, rect, text, callback, font_size=30):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.callback = callback
        self.hover = False
        self.font = self.load_font(font_size)

    def load_font(self, size):
        """加载字体"""
        try:
            return pygame.font.Font(resource_path(FONT_FILE), size)
        except:
            return pygame.font.SysFont("simhei", size)

    def draw(self, surface):
        """绘制按钮"""
        color = COLORS["BUTTON_HOVER"] if self.hover else COLORS["BUTTON"]
        pygame.draw.rect(surface, color, self.rect, border_radius=10)

        text_surf = self.font.render(self.text, True, COLORS["WHITE"])
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def handle_event(self, event):
        """处理事件"""
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and self.hover:
            self.callback()


class ScrollableList:
    """可滚动列表"""

    def __init__(self, rect, item_height):
        self.rect = pygame.Rect(rect)
        self.item_height = item_height
        self.scroll_offset = 0
        self.max_offset = 0

    def update(self, item_count):
        """更新滚动范围"""
        visible_items = self.rect.height // self.item_height
        self.max_offset = max(0, item_count - visible_items)

    def handle_event(self, event):
        """处理滚动事件"""
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_offset = max(0, min(
                self.scroll_offset - event.y * 3,
                self.max_offset
            ))


# ---------- 游戏核心类 ----------
class Snake:
    """贪吃蛇类"""

    def __init__(self):
        self.reset()

    def reset(self):
        """重置状态"""
        self.body = [
            [WINDOW_SIZE[0] // 2, WINDOW_SIZE[1] // 2],
            [WINDOW_SIZE[0] // 2 - CELL_SIZE, WINDOW_SIZE[1] // 2],
            [WINDOW_SIZE[0] // 2 - 2 * CELL_SIZE, WINDOW_SIZE[1] // 2]
        ]
        self.direction = "RIGHT"
        self.next_direction = "RIGHT"
        self.grow = False

    def move(self):
        """移动蛇身"""
        # 先更新方向（关键修改）
        self.direction = self.next_direction

        head = self.body[0].copy()
        direction_map = {
            "RIGHT": (CELL_SIZE, 0),
            "LEFT": (-CELL_SIZE, 0),
            "UP": (0, -CELL_SIZE),
            "DOWN": (0, CELL_SIZE)
        }
        dx, dy = direction_map[self.direction]
        head[0] += dx
        head[1] += dy

        self.body.insert(0, head)
        if not self.grow:
            self.body.pop()
        else:
            self.grow = False

    def check_collision(self):
        """碰撞检测"""
        head = self.body[0]
        if (head[0] < 0 or head[0] >= WINDOW_SIZE[0] or
                head[1] < 0 or head[1] >= WINDOW_SIZE[1]):
            return True
        return any(head == seg for seg in self.body[1:])


class Food:
    """食物类"""

    def __init__(self, snake):
        self.snake = snake
        self.position = self.random_position()

    def random_position(self):
        """生成随机位置"""
        grid_width = WINDOW_SIZE[0] // CELL_SIZE
        grid_height = WINDOW_SIZE[1] // CELL_SIZE
        attempts = 0

        while attempts < 1000:  # 防止无限循环
            x = random.randint(0, grid_width - 1) * CELL_SIZE
            y = random.randint(0, grid_height - 1) * CELL_SIZE
            if [x, y] not in self.snake.body:
                return [x, y]
            attempts += 1
        return [0, 0]  # 保底返回


# ---------- 游戏主逻辑 ----------
class Game:
    def __init__(self):
        self.state = STATES["MAIN_MENU"]
        self.snake = Snake()
        self.food = Food(self.snake)
        self.score = 0
        self.music_playing = False

        # 初始化UI组件
        self.init_ui()

        # 加载并播放背景音乐
        try:
            pygame.mixer.music.load(resource_path(MUSIC_FILE))
            pygame.mixer.music.set_volume(0.5)  # 设置音量，范围从 0.0 到 1.0
            pygame.mixer.music.play(-1)  # -1 表示无限循环播放
            self.music_playing = True
        except pygame.error as e:
            print(f"无法加载背景音乐: {e}")

    def init_ui(self):
        """初始化界面组件"""
        # 主菜单按钮
        btn_width, btn_height = 200, 50
        x_center = WINDOW_SIZE[0] // 2 - btn_width // 2
        self.main_menu_buttons = [
            Button((x_center, 300, btn_width, btn_height),
                   "开始游戏", lambda: self.set_state(STATES["GAME_ACTIVE"])),
            Button((x_center, 380, btn_width, btn_height),
                   "历史记录", lambda: self.set_state(STATES["VIEW_HIGHSCORES"])),
            Button((x_center, 460, btn_width, btn_height),
                   "退出游戏", lambda: self.quit_game())
        ]

        # 历史记录界面
        self.back_btn = Button((20, 20, 100, 40), "返回",
                               lambda: self.set_state(STATES["MAIN_MENU"]))
        self.highscore_list = ScrollableList((WINDOW_SIZE[0] // 2 - 150, 150, 300, 400), 50)

    def set_state(self, new_state):
        """状态切换"""
        if new_state == STATES["GAME_ACTIVE"]:
            self.snake.reset()
            self.food.position = self.food.random_position()
            self.score = 0
        self.state = new_state

    def handle_events(self):
        """处理事件"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit_game()

            # 根据状态分发事件
            if self.state == STATES["MAIN_MENU"]:
                for btn in self.main_menu_buttons:
                    btn.handle_event(event)
            elif self.state == STATES["VIEW_HIGHSCORES"]:
                self.back_btn.handle_event(event)
                self.highscore_list.handle_event(event)
            elif self.state == STATES["GAME_OVER"]:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        self.set_state(STATES["GAME_ACTIVE"])
                    elif event.key == pygame.K_ESCAPE:
                        self.set_state(STATES["MAIN_MENU"])
            elif self.state == STATES["GAME_ACTIVE"]:
                if event.type == pygame.KEYDOWN:
                    # 修改方向映射表（优化响应逻辑）
                    new_direction = {
                        pygame.K_RIGHT: "RIGHT",
                        pygame.K_LEFT: "LEFT",
                        pygame.K_UP: "UP",
                        pygame.K_DOWN: "DOWN"
                    }.get(event.key)

                    if new_direction:
                        # 禁止直接反向移动
                        current_dir = self.snake.direction
                        if (current_dir, new_direction) not in [
                            ("LEFT", "RIGHT"), ("RIGHT", "LEFT"),
                            ("UP", "DOWN"), ("DOWN", "UP")
                        ]:
                            self.snake.next_direction = new_direction

    def update(self):
        """更新游戏逻辑"""
        if self.state == STATES["GAME_ACTIVE"]:
            self.snake.move()

            # 碰撞检测
            if self.snake.check_collision():
                save_highscore(self.score)
                self.set_state(STATES["GAME_OVER"])

            # 食物获取
            if self.snake.body[0] == self.food.position:
                self.snake.grow = True
                self.score += 10
                self.food.position = self.food.random_position()

    def draw(self):
        """绘制界面"""
        screen.fill(COLORS["BLACK"])

        if self.state == STATES["MAIN_MENU"]:
            self.draw_main_menu()
        elif self.state == STATES["VIEW_HIGHSCORES"]:
            self.draw_highscores()
        elif self.state == STATES["GAME_ACTIVE"]:
            self.draw_game()
        elif self.state == STATES["GAME_OVER"]:
            self.draw_game_over()

        pygame.display.flip()
        clock.tick(15)

    def draw_main_menu(self):
        """主菜单界面"""
        # 标题
        title_font = self.main_menu_buttons[0].load_font(72)  # 直接加载新字体
        title = title_font.render("贪吃蛇大作战", True, COLORS["GREEN"])
        screen.blit(title, title.get_rect(center=(WINDOW_SIZE[0] // 2, 150)))

        # 按钮
        for btn in self.main_menu_buttons:
            btn.draw(screen)

    def draw_highscores(self):
        """历史记录界面"""
        # 标题
        title_font = self.back_btn.load_font(60)  # 使用按钮的字体加载方法
        title = title_font.render("历史记录", True, COLORS["WHITE"])
        screen.blit(title, title.get_rect(center=(WINDOW_SIZE[0] // 2, 80)))

        # 记录列表
        highscores = get_highscores()
        self.highscore_list.update(len(highscores))

        # 创建裁剪区域
        list_area = pygame.Rect(WINDOW_SIZE[0] // 2 - 150, 150, 300, 400)
        surf = pygame.Surface(list_area.size)
        surf.fill(COLORS["BLACK"])

        # 绘制记录项
        item_font = self.back_btn.load_font(36)  # 使用自定义字体
        visible_items = list_area.height // 50
        for i in range(self.highscore_list.scroll_offset,
                       min(len(highscores), self.highscore_list.scroll_offset + visible_items)):
            y_pos = (i - self.highscore_list.scroll_offset) * 50
            text = item_font.render(f"{i + 1}. {highscores[i]}", True, COLORS["WHITE"])
            surf.blit(text, (10, y_pos))

        # 绘制滚动条
        if len(highscores) > visible_items:
            scroll_height = list_area.height * (visible_items / len(highscores))
            scroll_pos = self.highscore_list.scroll_offset / len(highscores) * list_area.height
            pygame.draw.rect(surf, COLORS["SCROLLBAR"],
                             (list_area.width - 10, scroll_pos, 8, scroll_height))

        screen.blit(surf, list_area.topleft)
        self.back_btn.draw(screen)

    def draw_game(self):
        """游戏界面"""
        # 绘制网格
        for x in range(0, WINDOW_SIZE[0], CELL_SIZE):
            pygame.draw.line(screen, COLORS["GRID"], (x, 0), (x, WINDOW_SIZE[1]))
        for y in range(0, WINDOW_SIZE[1], CELL_SIZE):
            pygame.draw.line(screen, COLORS["GRID"], (0, y), (WINDOW_SIZE[0], y))

        # 绘制蛇
        for i, seg in enumerate(self.snake.body):
            color = (
                COLORS["GREEN"][0] * (1 - i / len(self.snake.body) * 0.3),
                COLORS["GREEN"][1] * (1 - i / len(self.snake.body) * 0.3),
                COLORS["GREEN"][2] * (1 - i / len(self.snake.body) * 0.3)
            )
            pygame.draw.rect(screen, color, (*seg, CELL_SIZE, CELL_SIZE))
            pygame.draw.rect(screen, COLORS["DARK_GREEN"], (*seg, CELL_SIZE, CELL_SIZE), 1)

        # 绘制食物
        pygame.draw.circle(screen, COLORS["RED"],
                           (self.food.position[0] + CELL_SIZE // 2,
                            self.food.position[1] + CELL_SIZE // 2),
                           CELL_SIZE // 2 - 2)

        # 绘制分数
        score_font = self.back_btn.load_font(30)  # 使用自定义字体
        text = score_font.render(f"得分: {self.score}", True, COLORS["WHITE"])
        screen.blit(text, (20, 20))

    def draw_game_over(self):
        """游戏结束界面"""
        overlay = pygame.Surface(WINDOW_SIZE, pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        # 标题
        title_font = self.back_btn.load_font(72)  # 使用自定义字体
        title = title_font.render("游戏结束!", True, COLORS["RED"])
        screen.blit(title, title.get_rect(center=(WINDOW_SIZE[0] // 2, 250)))

        # 分数
        score_font = self.back_btn.load_font(40)  # 使用自定义字体
        text = score_font.render(f"最终得分: {self.score}", True, COLORS["WHITE"])
        screen.blit(text, text.get_rect(center=(WINDOW_SIZE[0] // 2, 320)))


        # 提示
        hint_font = self.back_btn.load_font(30)  # 使用自定义字体
        hint = hint_font.render("按空格键重新开始  ESC返回菜单", True, COLORS["WHITE"])
        screen.blit(hint, hint.get_rect(center=(WINDOW_SIZE[0] // 2, 380)))

    def run(self):
        """运行游戏"""
        while True:
            self.handle_events()
            self.update()
            self.draw()


if __name__ == "__main__":
    game = Game()
    game.run()